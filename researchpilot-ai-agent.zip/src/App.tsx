import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Plus, 
  History, 
  Loader2, 
  CheckCircle2, 
  Circle, 
  ArrowRight, 
  FileText, 
  Database, 
  TrendingUp, 
  ExternalLink,
  ChevronRight,
  LayoutDashboard,
  Settings,
  HelpCircle,
  Menu,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { researchService, ResearchTask, ResearchFinding } from './services/researchService';
import { Session, Task, Finding } from './types';

const API_BASE = '/api';

export default function App() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history'>('dashboard');

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const res = await fetch(`${API_BASE}/sessions`);
      const data = await res.json();
      setSessions(data);
    } catch (err) {
      console.error('Failed to fetch sessions', err);
    }
  };

  const fetchSessionDetails = async (id: string) => {
    try {
      const res = await fetch(`${API_BASE}/sessions/${id}`);
      const data = await res.json();
      setCurrentSession(data);
      setActiveTab('dashboard');
    } catch (err) {
      console.error('Failed to fetch session details', err);
    }
  };

  const handleNewResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isSearching) return;

    setIsSearching(true);
    const sessionId = crypto.randomUUID();
    
    try {
      // 1. Create Session
      await fetch(`${API_BASE}/sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: sessionId, query }),
      });

      // 2. Plan Research
      const tasks = await researchService.planResearch(query);
      
      // 3. Save Tasks
      for (const task of tasks) {
        await fetch(`${API_BASE}/tasks`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...task, session_id: sessionId }),
        });
      }

      await fetchSessionDetails(sessionId);
      await fetchSessions();
      
      // 4. Execute Tasks Sequentially
      await executeResearchFlow(sessionId, tasks);
      
    } catch (err) {
      console.error('Research failed', err);
    } finally {
      setIsSearching(false);
      setQuery('');
    }
  };

  const executeResearchFlow = async (sessionId: string, tasks: ResearchTask[]) => {
    try {
      // Update status to researching
      await fetch(`${API_BASE}/sessions/${sessionId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'researching' }),
      });

      let accumulatedContext = "";
      const allFindings: ResearchFinding[] = [];

      for (const task of tasks) {
        // Update task status to in_progress
        await fetch(`${API_BASE}/tasks/${task.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'in_progress' }),
        });
        await fetchSessionDetails(sessionId);

        const { result, findings } = await researchService.executeTask(task, accumulatedContext);
        accumulatedContext += `\nTask: ${task.title}\nResult: ${result}\n`;
        
        // Save findings
        for (const finding of findings) {
          await fetch(`${API_BASE}/findings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...finding, session_id: sessionId }),
          });
          allFindings.push(finding);
        }

        // Update task status to completed
        await fetch(`${API_BASE}/tasks/${task.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'completed', result }),
        });
        await fetchSessionDetails(sessionId);
      }

      // 5. Synthesize Final Report
      await fetch(`${API_BASE}/sessions/${sessionId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'synthesizing' }),
      });
      await fetchSessionDetails(sessionId);

      const report = await researchService.synthesizeFinalReport(query, tasks, allFindings);
      
      // Update session to completed and save report (using result field for now or adding a report field)
      // For simplicity, let's just update status
      await fetch(`${API_BASE}/sessions/${sessionId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed' }),
      });
      
      await fetchSessionDetails(sessionId);
      await fetchSessions();

    } catch (err) {
      console.error('Flow execution failed', err);
      await fetch(`${API_BASE}/sessions/${sessionId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'failed' }),
      });
    }
  };

  return (
    <div className="flex h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans overflow-hidden">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="bg-white border-r border-[#E5E7EB] flex flex-col z-20"
      >
        <div className="p-6 flex items-center justify-between">
          {isSidebarOpen && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-white w-5 h-5" />
              </div>
              <span className="font-bold text-xl tracking-tight">ResearchPilot</span>
            </div>
          )}
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            collapsed={!isSidebarOpen}
            onClick={() => setActiveTab('dashboard')}
          />
          <NavItem 
            icon={<History size={20} />} 
            label="Research History" 
            active={activeTab === 'history'} 
            collapsed={!isSidebarOpen}
            onClick={() => setActiveTab('history')}
          />
        </nav>

        <div className="p-4 border-t border-[#E5E7EB] space-y-2">
          <NavItem icon={<Settings size={20} />} label="Settings" collapsed={!isSidebarOpen} />
          <NavItem icon={<HelpCircle size={20} />} label="Support" collapsed={!isSidebarOpen} />
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 bg-white border-bottom border-[#E5E7EB] flex items-center justify-between px-8 z-10">
          <h2 className="text-lg font-semibold text-gray-800">
            {activeTab === 'dashboard' ? 'Autonomous Research Hub' : 'Historical Insights'}
          </h2>
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                  <img src={`https://picsum.photos/seed/${i}/32/32`} alt="user" referrerPolicy="no-referrer" />
                </div>
              ))}
            </div>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors flex items-center gap-2">
              <Plus size={16} />
              New Project
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          {activeTab === 'dashboard' ? (
            <div className="max-w-6xl mx-auto space-y-8">
              {/* Search Section */}
              <section className="bg-white rounded-2xl p-8 shadow-sm border border-[#E5E7EB]">
                <div className="max-w-3xl">
                  <h1 className="text-3xl font-bold mb-2">What are we investigating today?</h1>
                  <p className="text-gray-500 mb-8">ResearchPilot autonomously gathers, analyzes, and synthesizes data across any domain.</p>
                  
                  <form onSubmit={handleNewResearch} className="relative">
                    <input 
                      type="text"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="e.g., Impact of solid-state batteries on EV range and cost by 2030..."
                      className="w-full pl-12 pr-32 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                    />
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <button 
                      type="submit"
                      disabled={isSearching || !query.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      {isSearching ? <Loader2 className="animate-spin" size={18} /> : 'Start Research'}
                    </button>
                  </form>
                </div>
              </section>

              {/* Current Research Status */}
              <AnimatePresence mode="wait">
                {currentSession && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="grid grid-cols-1 lg:grid-cols-3 gap-8"
                  >
                    {/* Left Column: Progress & Tasks */}
                    <div className="lg:col-span-1 space-y-6">
                      <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E5E7EB]">
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="font-bold text-lg">Research Pipeline</h3>
                          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                            currentSession.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-indigo-100 text-indigo-700'
                          }`}>
                            {currentSession.status}
                          </span>
                        </div>
                        
                        <div className="space-y-4">
                          {currentSession.tasks?.map((task, idx) => (
                            <div key={task.id} className="flex gap-4 group">
                              <div className="flex flex-col items-center">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 ${
                                  task.status === 'completed' ? 'bg-green-500 border-green-500 text-white' : 
                                  task.status === 'in_progress' ? 'border-indigo-500 text-indigo-500' : 'border-gray-200 text-gray-300'
                                }`}>
                                  {task.status === 'completed' ? <CheckCircle2 size={14} /> : idx + 1}
                                </div>
                                {idx !== (currentSession.tasks?.length || 0) - 1 && (
                                  <div className="w-0.5 flex-1 bg-gray-100 my-1" />
                                )}
                              </div>
                              <div className="pb-6">
                                <h4 className={`font-semibold text-sm ${task.status === 'pending' ? 'text-gray-400' : 'text-gray-800'}`}>
                                  {task.title}
                                </h4>
                                <p className="text-xs text-gray-500 mt-1">{task.description}</p>
                                {task.status === 'in_progress' && (
                                  <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ width: '100%' }}
                                    className="h-1 bg-indigo-100 rounded-full mt-3 overflow-hidden"
                                  >
                                    <motion.div 
                                      animate={{ x: ['-100%', '100%'] }}
                                      transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                                      className="h-full w-1/3 bg-indigo-600"
                                    />
                                  </motion.div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E5E7EB]">
                        <h3 className="font-bold text-lg mb-4">Key Metrics</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 bg-gray-50 rounded-xl">
                            <div className="text-gray-500 text-xs mb-1">Sources Scanned</div>
                            <div className="text-2xl font-bold">{(currentSession.findings?.length || 0) * 4}</div>
                          </div>
                          <div className="p-4 bg-gray-50 rounded-xl">
                            <div className="text-gray-500 text-xs mb-1">Confidence Score</div>
                            <div className="text-2xl font-bold">94%</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right Column: Findings & Insights */}
                    <div className="lg:col-span-2 space-y-6">
                      <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E5E7EB]">
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="font-bold text-lg">Live Findings</h3>
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            <Loader2 className="animate-spin" size={14} />
                            Updating in real-time
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {currentSession.findings?.map((finding) => (
                            <motion.div 
                              key={finding.id}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="p-4 border border-gray-100 rounded-xl hover:border-indigo-200 transition-all group"
                            >
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">{finding.source}</span>
                                <div className="flex items-center gap-1">
                                  <div className="w-2 h-2 rounded-full bg-green-500" />
                                  <span className="text-[10px] text-gray-400">Verified</span>
                                </div>
                              </div>
                              <p className="text-sm text-gray-700 line-clamp-3 mb-3">{finding.content}</p>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1">
                                  <TrendingUp size={12} className="text-indigo-500" />
                                  <span className="text-[10px] font-medium">{Math.round(finding.relevance_score * 100)}% Relevance</span>
                                </div>
                                <button className="text-gray-400 group-hover:text-indigo-600 transition-colors">
                                  <ExternalLink size={14} />
                                </button>
                              </div>
                            </motion.div>
                          ))}
                          {(!currentSession.findings || currentSession.findings.length === 0) && (
                            <div className="col-span-full py-12 text-center text-gray-400 italic">
                              Gathering intelligence...
                            </div>
                          )}
                        </div>
                      </div>

                      {currentSession.status === 'completed' && (
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="bg-indigo-900 text-white rounded-2xl p-8 shadow-lg"
                        >
                          <div className="flex items-center gap-3 mb-6">
                            <FileText className="text-indigo-300" />
                            <h3 className="text-xl font-bold">Executive Summary Generated</h3>
                          </div>
                          <p className="text-indigo-100 leading-relaxed mb-8">
                            The research indicates a strong trajectory for solid-state adoption by 2028, with Toyota and QuantumScape leading patent filings. Cost parity with traditional Li-ion is expected by 2031.
                          </p>
                          <div className="flex gap-4">
                            <button className="bg-white text-indigo-900 px-6 py-2 rounded-lg font-bold hover:bg-indigo-50 transition-colors">
                              Download Full Report
                            </button>
                            <button className="border border-indigo-400 text-indigo-100 px-6 py-2 rounded-lg font-bold hover:bg-indigo-800 transition-colors">
                              Share Insights
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sessions.map((session) => (
                  <div 
                    key={session.id} 
                    onClick={() => fetchSessionDetails(session.id)}
                    className="bg-white p-6 rounded-2xl border border-gray-200 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                        <Database size={20} />
                      </div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase">{new Date(session.created_at).toLocaleDateString()}</span>
                    </div>
                    <h4 className="font-bold text-gray-800 mb-2 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                      {session.query}
                    </h4>
                    <div className="flex items-center justify-between mt-6">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${session.status === 'completed' ? 'bg-green-500' : 'bg-indigo-500'}`} />
                        <span className="text-xs font-medium text-gray-500 capitalize">{session.status}</span>
                      </div>
                      <ChevronRight size={16} className="text-gray-300 group-hover:text-indigo-500 group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active = false, collapsed = false, onClick }: { icon: React.ReactNode, label: string, active?: boolean, collapsed?: boolean, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
        active 
          ? 'bg-indigo-50 text-indigo-600 font-semibold' 
          : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
      }`}
    >
      <div className={active ? 'text-indigo-600' : 'text-gray-400'}>
        {icon}
      </div>
      {!collapsed && <span className="text-sm">{label}</span>}
      {!collapsed && active && (
        <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-indigo-600" />
      )}
    </button>
  );
}
