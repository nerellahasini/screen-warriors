import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface ResearchTask {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  result?: string;
}

export interface ResearchFinding {
  id: string;
  source: string;
  content: string;
  relevance_score: number;
}

export const researchService = {
  async planResearch(query: string): Promise<ResearchTask[]> {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a Research Task Planner. Break down the following research query into 3-5 logical, sequential tasks for an autonomous agent to execute.
      Query: "${query}"
      
      Return the tasks in a structured JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
            },
            required: ["id", "title", "description"]
          }
        }
      }
    });

    try {
      const tasks = JSON.parse(response.text || "[]");
      return tasks.map((t: any) => ({ ...t, status: 'pending' }));
    } catch (e) {
      console.error("Failed to parse research plan", e);
      return [];
    }
  },

  async executeTask(task: ResearchTask, context: string): Promise<{ result: string; findings: ResearchFinding[] }> {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Execute the following research task:
      Task: ${task.title}
      Description: ${task.description}
      Context so far: ${context}
      
      Use Google Search to find real, credible information. 
      Synthesize your findings and provide a detailed result.
      Also, extract key findings with their sources.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            result: { type: Type.STRING, description: "Detailed synthesis of the task execution" },
            findings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  source: { type: Type.STRING },
                  content: { type: Type.STRING },
                  relevance_score: { type: Type.NUMBER }
                },
                required: ["id", "source", "content", "relevance_score"]
              }
            }
          },
          required: ["result", "findings"]
        }
      }
    });

    try {
      return JSON.parse(response.text || '{"result": "", "findings": []}');
    } catch (e) {
      console.error("Failed to parse task execution", e);
      return { result: "Error executing task", findings: [] };
    }
  },

  async synthesizeFinalReport(query: string, tasks: ResearchTask[], findings: ResearchFinding[]): Promise<string> {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a comprehensive research report for the original query: "${query}"
      
      Based on the following tasks executed:
      ${tasks.map(t => `- ${t.title}: ${t.result}`).join('\n')}
      
      And these key findings:
      ${findings.map(f => `- [${f.source}]: ${f.content}`).join('\n')}
      
      The report should be professional, structured with headings, and include an executive summary, key insights, and a conclusion. Use Markdown.`,
    });

    return response.text || "Failed to generate report.";
  }
};
