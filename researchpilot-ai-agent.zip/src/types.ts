export interface Session {
  id: string;
  query: string;
  status: 'planning' | 'researching' | 'synthesizing' | 'completed' | 'failed';
  created_at: string;
  tasks?: Task[];
  findings?: Finding[];
  report?: string;
}

export interface Task {
  id: string;
  session_id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  result?: string;
  created_at: string;
}

export interface Finding {
  id: string;
  session_id: string;
  source: string;
  content: string;
  relevance_score: number;
  created_at: string;
}
