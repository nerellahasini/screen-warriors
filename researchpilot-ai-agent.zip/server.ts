import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("research.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    query TEXT,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    title TEXT,
    description TEXT,
    status TEXT,
    result TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(session_id) REFERENCES sessions(id)
  );

  CREATE TABLE IF NOT EXISTS findings (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    source TEXT,
    content TEXT,
    relevance_score REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(session_id) REFERENCES sessions(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/sessions", (req, res) => {
    const sessions = db.prepare("SELECT * FROM sessions ORDER BY created_at DESC").all();
    res.json(sessions);
  });

  app.post("/api/sessions", (req, res) => {
    const { id, query } = req.body;
    db.prepare("INSERT INTO sessions (id, query, status) VALUES (?, ?, ?)").run(id, query, "planning");
    res.json({ success: true });
  });

  app.get("/api/sessions/:id", (req, res) => {
    const session = db.prepare("SELECT * FROM sessions WHERE id = ?").get(req.params.id);
    const tasks = db.prepare("SELECT * FROM tasks WHERE session_id = ?").all(req.params.id);
    const findings = db.prepare("SELECT * FROM findings WHERE session_id = ?").all(req.params.id);
    res.json({ ...session, tasks, findings });
  });

  app.post("/api/tasks", (req, res) => {
    const { id, session_id, title, description, status } = req.body;
    db.prepare("INSERT INTO tasks (id, session_id, title, description, status) VALUES (?, ?, ?, ?, ?)")
      .run(id, session_id, title, description, status);
    res.json({ success: true });
  });

  app.patch("/api/tasks/:id", (req, res) => {
    const { status, result } = req.body;
    db.prepare("UPDATE tasks SET status = ?, result = ? WHERE id = ?").run(status, result, req.params.id);
    res.json({ success: true });
  });

  app.post("/api/findings", (req, res) => {
    const { id, session_id, source, content, relevance_score } = req.body;
    db.prepare("INSERT INTO findings (id, session_id, source, content, relevance_score) VALUES (?, ?, ?, ?, ?)")
      .run(id, session_id, source, content, relevance_score);
    res.json({ success: true });
  });

  app.patch("/api/sessions/:id/status", (req, res) => {
    const { status } = req.body;
    db.prepare("UPDATE sessions SET status = ? WHERE id = ?").run(status, req.params.id);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
